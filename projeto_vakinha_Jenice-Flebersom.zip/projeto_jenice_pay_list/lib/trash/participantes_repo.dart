class Pessoa {
  String nome;

  Pessoa({required this.nome});
}

class PessoaRepo {
  static List<Pessoa> tabela = [
    Pessoa(nome: 'Maria Góia'),
    Pessoa(nome: 'Adriana Torta'),
    Pessoa(nome: 'José da Guia'),
    Pessoa(nome: 'João Gárgula'),
    Pessoa(nome: 'Paulo Polento'),
    Pessoa(nome: 'Pedro Barra'),
    Pessoa(nome: 'Mariana Mar'),
    Pessoa(nome: 'Luiz Zebra'),
    Pessoa(nome: 'Emeci Dônaites'),
    Pessoa(nome: 'Mariinha Talco'),
    Pessoa(nome: 'Izabela Friso'),
    Pessoa(nome: 'Andréia Flerte'),
  ];
}
