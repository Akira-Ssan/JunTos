package com.example.projeto_jenice_pay_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
