# Projeto JunTos
# FATECRP

# Professor: Rodrigo Plotz
# Alunos: Flebersom Bezerra, Jenice Júlio.

Projeto desenvolvido na FATEC de Ribeirão Preto, turma da manhã, 4* semestre 
na matéria eletiva de programação para dispositivos móveis.

Este projeto de software aspira ser um administrador de compras 
coletivas (administração de vaquinha), inicialmente para smartphone 
android. As funções esperadas do aplicativo são: permitir que o usuário 
cadastre produtos/viagens/qualquer coisa precificável que um grupo de pessoas
almeja comprar/adquirir de forma coletiva; deve também poder cadastrar as pessoas interessadas em participar; deve receber as informações dos pagamentos feitos pelos
participantes; deve processar e exibir informações sobre o andamento da 'vaquinha'
até que se atinja a meta estabelcida do valor do objeto.  

O projeto no estado que está serve apenas como um protótipo visual. Abstendo-se assim
de qualquer responsabilidade funcional. ^'qp'^

